from enum import Enum

class Font(Enum):
    TITLE = "Arial"
    TEXT = "Farsan-Regular"
    BODY = "Roboto"
    OSWALD = "Oswald-Regular-400"
