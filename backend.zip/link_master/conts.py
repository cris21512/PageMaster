#Comunidad 

TWITCH = "https://www.twitch.tv/elcris215"
YOUTUBE = "https://www.youtube.com/@RNFUNTS"
CDW = "https://whatsapp.com/channel/0029Vax4q9R8vd1OVwfuAD3d"
TIKTOK = "https://www.tiktok.com/@chito2.1.2"

#RECETAS 

#RES

ASADO = "https://www.tiktok.com/@chito2.1.2/video/7409379959845719302"
FAJITAS = "https://www.tiktok.com/@chito2.1.2/video/7419463973147315462"
TACRES = "https://www.tiktok.com/@chito2.1.2/video/7393498573494603014"
TORHAR = "https://www.tiktok.com/@chito2.1.2/video/7372350291674467589"
ALBONDIGAS = "https://www.tiktok.com/@chito2.1.2/video/7366402643129879813"
RAVIOLES = "https://www.tiktok.com/@chito2.1.2/video/7321849427122179333"
TORTITAS = "https://www.tiktok.com/@chito2.1.2/video/7295538203698793734"
PLANCHA = "https://www.tiktok.com/@chito2.1.2/video/7290692940182113541"
GARNA = "https://www.tiktok.com/@chito2.1.2/video/7286215363228962054"
TACPASTOR = "https://www.tiktok.com/@chito2.1.2/video/7283636966900501765"
LASAÑA = "https://www.tiktok.com/@chito2.1.2/video/7282912446346579206"
ENCHILADAS = "https://www.tiktok.com/@chito2.1.2/video/7280693963235872005"
CALDORES = "https://www.tiktok.com/@chito2.1.2/video/7280319803120717061"
HILACHAS = "https://www.tiktok.com/@chito2.1.2/video/7275043341216042245"
BIRRIA = "https://www.tiktok.com/@chito2.1.2/video/7269865927246679302"
SALPICON = "https://www.tiktok.com/@chito2.1.2/video/7268039258626067718"
BURGUERS = "https://www.tiktok.com/@chito2.1.2/video/7420961367986883845"
DOBRES = "https://www.tiktok.com/@chito2.1.2/video/7413525536913345797"
CHIRELLENOS = "https://www.tiktok.com/@chito2.1.2/video/7276224556853955845"
BISTEC = "https://www.tiktok.com/@chito2.1.2/video/7271686528600984837"


#POLLO

FREIDORA = "https://www.tiktok.com/@chito2.1.2/video/7416126140466711813"
ARROZCHINO = "https://www.tiktok.com/@chito2.1.2/video/7377528806975786245"
CALDOGALLINA = "https://www.tiktok.com/@chito2.1.2/video/7376448310292385030"
HORNEADO = "https://www.tiktok.com/@chito2.1.2/video/7367520085583416581"
PEPIAN = "https://www.tiktok.com/@chito2.1.2/video/7307403253111622918"
CHAOMEIN = "https://www.tiktok.com/@chito2.1.2/video/7276985491331828998"
PANCONPOLLO = "https://www.tiktok.com/@chito2.1.2/video/7274002976971230470"
POLLOCREMA = "https://www.tiktok.com/@chito2.1.2/video/7273611447085714694"
POLLOFRITO = "https://www.tiktok.com/@chito2.1.2/video/7272491369854291206"
JOCON = "https://www.tiktok.com/@chito2.1.2/video/7291047464079985926"

#CERDO

PUPUSAS = "https://www.tiktok.com/@chito2.1.2/video/7294792774719720709"
CARNITAS = "https://www.tiktok.com/@chito2.1.2/video/7291828034351549702"
FRIJOBLANCO = "https://www.tiktok.com/@chito2.1.2/video/7277684337804381445"
FRJOLCOLORADO = "https://www.tiktok.com/@chito2.1.2/video/7270574061468568837"
CHICHACOLORAO = "https://www.tiktok.com/@chito2.1.2/video/7298494811928071429"

#PESCADO

CALDODMARISCOS = "https://www.tiktok.com/@chito2.1.2/video/7340811194237799686"
AGUACHILE = "https://www.tiktok.com/@chito2.1.2/video/7285849249198148870"
CEVICHE = "https://www.tiktok.com/@chito2.1.2/video/7279623788755684614"
MOJARRA = "https://www.tiktok.com/@chito2.1.2/video/7275406354280353030"

#IMAGES

FAVICON = "https://drive.google.com/file/d/1BMpexEgAcGJpG_oj_91sUp6huDDxtYTB/view?usp=sharing"
